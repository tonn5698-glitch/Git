scoreboard objectives add custom.tmp dummy
scoreboard objectives add custom.tier dummy
scoreboard objectives add custom.cfg dummy
# 1 = sneaking while placing builds normally (no break). 0 = strict mode.
execute unless score #sneak_builds custom.cfg matches 0.. run scoreboard players set #sneak_builds custom.cfg 1
