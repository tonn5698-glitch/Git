advancement revoke @s only custom:place/t1
scoreboard players set @s custom.tier 1
function custom:place/start
