advancement revoke @s only custom:place/t3
scoreboard players set @s custom.tier 3
function custom:place/start
