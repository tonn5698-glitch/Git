advancement revoke @s only custom:place/t0
scoreboard players set @s custom.tier 0
function custom:place/start
