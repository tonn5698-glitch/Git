advancement revoke @s only custom:place/t4
scoreboard players set @s custom.tier 4
function custom:place/start
