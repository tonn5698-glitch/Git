advancement revoke @s only custom:place/t2
scoreboard players set @s custom.tier 2
function custom:place/start
