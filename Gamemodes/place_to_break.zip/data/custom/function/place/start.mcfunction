execute if score #sneak_builds custom.cfg matches 1 if predicate custom:sneaking run return 0
scoreboard players set #steps custom.tmp 0
scoreboard players set #hasx custom.tmp 0
scoreboard players set #done custom.tmp 0
execute at @s anchored eyes positioned ^ ^ ^ anchored feet run function custom:ray/step
kill @e[type=marker,tag=custom.placed]
