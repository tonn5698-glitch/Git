# as player, positioned at target block center
execute unless entity @e[type=marker,tag=custom.placed,distance=..1.01] run return 0
scoreboard players set #bt custom.tmp -1
execute if block ~ ~ ~ #custom:breakable/t0 run scoreboard players set #bt custom.tmp 0
execute if block ~ ~ ~ #custom:breakable/t1 run scoreboard players set #bt custom.tmp 1
execute if block ~ ~ ~ #custom:breakable/t2 run scoreboard players set #bt custom.tmp 2
execute if block ~ ~ ~ #custom:breakable/t3 run scoreboard players set #bt custom.tmp 3
execute if block ~ ~ ~ #custom:breakable/t4 run scoreboard players set #bt custom.tmp 4
execute unless score #bt custom.tmp matches 0.. run return 0
execute unless score @s custom.tier >= #bt custom.tmp run return 0
# refund placed block (silk-touch loot = exact item), remove it, break target with normal drops
scoreboard players set #r custom.tmp 0
execute unless entity @s[gamemode=creative] at @e[type=marker,tag=custom.placed] run function custom:refund
execute at @e[type=marker,tag=custom.placed] run setblock ~ ~ ~ air
setblock ~ ~ ~ air destroy
