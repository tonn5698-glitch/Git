scoreboard players set #hasx custom.tmp 1
execute align xyz run summon marker ~0.5 ~0.5 ~0.5 {Tags:["custom.placed"]}
