# still inside the placed block's cell
execute align xyz if entity @e[type=marker,tag=custom.placed,dx=0,dy=0,dz=0] run return 0
# first solid cell must be a placer block, else the placed block was missed: abort safely
execute if score #hasx custom.tmp matches 0 unless block ~ ~ ~ #custom:placer_blocks run return run function custom:ray/abort
# first solid cell = the placed block
execute if score #hasx custom.tmp matches 0 run return run function custom:ray/mark
# next solid cell = clicked target
scoreboard players set #done custom.tmp 1
execute align xyz positioned ~0.5 ~0.5 ~0.5 run function custom:ray/target
