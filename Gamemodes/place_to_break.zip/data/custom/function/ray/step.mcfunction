scoreboard players add #steps custom.tmp 1
execute unless block ~ ~ ~ #custom:passthrough run function custom:ray/hit
execute if score #done custom.tmp matches 0 if score #steps custom.tmp matches ..560 positioned ^ ^ ^0.01 run function custom:ray/step
