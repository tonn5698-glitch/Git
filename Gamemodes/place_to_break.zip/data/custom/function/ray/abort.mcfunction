scoreboard players set #done custom.tmp 1
